import express from 'express';
import { WebSocketServer } from 'ws';
import { getGrokReply } from './xaiProxy.js';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

const wss = new WebSocketServer({ server });

wss.on('connection', ws => {
  console.log('Client connected');

  ws.on('message', async message => {
    try {
      const data = JSON.parse(message);
      if (data.text) {
        const botReply = await getGrokReply(data.text);
        const replyMsg = {
          user: 'Grok',
          text: botReply,
          profilePic: ''
        };
        ws.send(JSON.stringify(replyMsg));
      }

      wss.clients.forEach(client => {
        if (client.readyState === ws.OPEN) {
          client.send(message);
        }
      });
    } catch (err) {
      console.error('Error:', err);
    }
  });

  ws.on('close', () => console.log('Client disconnected'));
});