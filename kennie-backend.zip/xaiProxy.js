import fetch from 'node-fetch';
import dotenv from 'dotenv';
dotenv.config();

export async function getGrokReply(message) {
  const res = await fetch('https://api.x.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.XAI_API_KEY}`
    },
    body: JSON.stringify({
      model: 'grok-3',
      messages: [
        { role: 'system', content: 'You are Grok, a helpful AI created by xAI.' },
        { role: 'user', content: message }
      ],
      max_tokens: 200,
      temperature: 0.7
    }),
  });

  const data = await res.json();
  return data.choices[0]?.message?.content?.trim() || "No response.";
}